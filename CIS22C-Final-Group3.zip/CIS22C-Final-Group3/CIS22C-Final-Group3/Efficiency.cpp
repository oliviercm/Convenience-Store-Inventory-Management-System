#include "Efficiency.h"

int Efficiency::globalArrayOperations = 0;
int Efficiency::globalListOperations = 0;
int Efficiency::globalHashOperations = 0;
int Efficiency::globalBinaryTreeOperations = 0;